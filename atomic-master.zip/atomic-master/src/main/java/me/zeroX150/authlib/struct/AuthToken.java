package me.zeroX150.authlib.struct;

/**
 * The class Authentication token.
 */
public abstract class AuthToken {

}
