/*
 * This file is part of the atomic client distribution.
 * Copyright (c) 2021 0x150.
 */

package me.zeroX150.atomic.feature.gui.screen;

public interface NonClearingInit {

}
