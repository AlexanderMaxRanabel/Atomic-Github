/*
 * This file is part of the atomic client distribution.
 * Copyright (c) 2021-2021 0x150.
 */

package me.zeroX150.atomic;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "You ran me as an executable. Dont do that. You are supposed to drag me into your mods folder, not run me", "Error", JOptionPane.WARNING_MESSAGE);
    }
}
