package me.zeroX150.atomic.helper.event.events;

import me.zeroX150.atomic.helper.event.events.base.NonCancellableEvent;

public class PostInitEvent extends NonCancellableEvent {

}
