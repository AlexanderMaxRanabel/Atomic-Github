# where download?

in the builds folder

dont ask for it again you retards

releases are outdated, use the link on there, if you click it

## if your clickgui looks like this, you fucked it up

![image](https://user-images.githubusercontent.com/80022388/127568588-56fb5c5b-bec0-41f6-99f1-4deb87f7ab1a.png)
